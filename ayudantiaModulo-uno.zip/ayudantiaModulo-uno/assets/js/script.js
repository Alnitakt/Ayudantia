alert("Bienvenido a la ayudantía!")

console.log("bienvenido a la consola")
